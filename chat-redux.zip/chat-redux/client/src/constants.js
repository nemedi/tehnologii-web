export const LOGIN = 'login';
export const LOGOUT = 'logout';
export const SEND = 'send';
export const RECEIVE = 'receive';
export const CHAT = 'chat';
export const ENDPOINT = 'ws://localhost:8080';